#include <iostream>

#include "CipherFile.h"
#include "CipherList.h"
#include "MessageFile.h"
#include "gtest_lite.h"
#include "memtrace.h"




int main(int argc, char *argv[]) {
    try {

        return 0;
    } catch (std::exception &e) {
        std::cerr << e.what() << std::endl;
    }
}
